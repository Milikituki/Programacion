package model;

public class Campeonato {
    private Coche[] coches;

    public Campeonato(Coche[] coches){
        this.coches = coches;
    }

    public Coche[] getCoches() {
        return coches;
    }
}
